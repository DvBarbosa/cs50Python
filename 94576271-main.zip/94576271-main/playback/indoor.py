frase = input("Insira uma frase: ")
y = frase.lower()
print("Frase em minúsculas:", y)
