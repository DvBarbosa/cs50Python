mensagem = input("insira mensagem: ")
mensagem = mensagem.replace(" ", "...")
print(mensagem)